'use strict';

self.addEventListener('install', event => {

});

self.addEventListener('fetch', event => {

});

self.addEventListener('message', event => {

});